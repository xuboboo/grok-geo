# geo-brand-audit

版本：1.0.0

一次性 AI 搜索 / GEO 品牌诊断 Skill。通过 `web_search` 采集证据，用标准库 Python 脚本做确定性指标与报告生成。

## 目录

- `SKILL.md` — Agent 工作流与约束
- `scripts/` — 确定性 CLI 脚本
- `schemas/` — JSON Schema
- `examples/` — 最小/完整输入与 offline fixture
- `references/` — 规则说明
- `templates/` — 报告模板片段
- `evals/` — 轻量评估用例

## 本地 offline 演示

```bash
python examples/run_offline_demo.py --base-dir ./geo-audit-runs --keep
```

产物位于 `geo-audit-runs/geo_offline_demo_00000001/output/`。

## 脚本列表

| 脚本 | 作用 |
| --- | --- |
| validate_input.py | 输入 Schema + 业务校验 |
| initialize_run.py | 创建 run 目录与 manifest |
| update_manifest.py | 更新状态/计数 |
| validate_questions.py | 问题比例约束 |
| append_search_result.py | 追加 search_results.jsonl |
| normalize_entities.py | 实体名规范化 |
| normalize_urls.py | URL 规范化 |
| classify_citations.py | 引用分类 |
| calculate_metrics.py | 确定性指标 |
| rank_opportunities.py | 机会评分排序（≤10） |
| render_report.py | report.md/json + CSV |
| validate_report.py | 报告一致性与 URL 追溯 |
| package_outputs.py | 输出打包 |

运行环境默认 runs 目录：

- Hosted：`/mnt/data/geo-audit-runs`
- Local：`GEO_AUDIT_RUNS_DIR` 或 `./geo-audit-runs`