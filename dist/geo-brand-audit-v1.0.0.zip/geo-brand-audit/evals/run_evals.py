#!/usr/bin/env python3
"""Lightweight eval runner for geo-brand-audit (no model calls)."""

from __future__ import annotations

import csv
import json
import sys
from pathlib import Path

EVAL_DIR = Path(__file__).resolve().parent
SKILL_ROOT = EVAL_DIR.parent
SCRIPTS = SKILL_ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from geo_common import position_score, rate_with_ci  # noqa: E402
from rank_opportunities import score_opportunity  # noqa: E402


def eval_metric_fixtures() -> list[dict]:
    data = json.loads((EVAL_DIR / "metric-fixtures.json").read_text(encoding="utf-8"))
    results = []
    for fix in data["fixtures"]:
        exp = fix["expected"]
        mr = rate_with_ci(fix["brand_mentions"], fix["valid_answers"])["rate"]
        rr = rate_with_ci(fix["brand_recommendations"], fix["recommendation_answers"])["rate"]
        oc = rate_with_ci(fix["owned_citation_answers"], fix["valid_answers"])["rate"]
        ok = True
        msgs = []
        for name, got, want in [
            ("mention_rate", mr, exp["mention_rate"]),
            ("recommendation_rate", rr, exp["recommendation_rate"]),
            ("owned_citation_rate", oc, exp["owned_citation_rate"]),
        ]:
            if want is None and got is None:
                continue
            if want is None or got is None or abs(got - want) > 1e-9:
                ok = False
                msgs.append(f"{name}: got {got} want {want}")
        results.append({"id": fix["id"], "ok": ok, "detail": "; ".join(msgs)})

    for i, row in enumerate(data.get("position_scores") or []):
        got = position_score(row["mention_type"], row.get("rank"))
        ok = abs(got - row["expected"]) < 1e-9
        results.append(
            {
                "id": f"POS{i+1}",
                "ok": ok,
                "detail": "" if ok else f"got {got} want {row['expected']}",
            }
        )

    for i, row in enumerate(data.get("opportunity_scores") or []):
        got = score_opportunity(row["scores"])
        ok = abs(got - row["expected_total"]) < 1e-9
        results.append(
            {
                "id": f"OPP{i+1}",
                "ok": ok,
                "detail": "" if ok else f"got {got} want {row['expected_total']}",
            }
        )
    return results


def eval_trigger_heuristic() -> list[dict]:
    """Keyword heuristic proxy for skill description matching (not a model)."""
    positive_kw = (
        "geo",
        "ai搜索",
        "ai 搜索",
        "品牌诊断",
        "品牌审计",
        "引用",
        "推荐我的竞争",
        "visibility",
        "chatgpt",
        "诊断",
        "曝光",
        "perplexity",
        "claude",
        "引用率",
        "推荐份额",
        "generative engine",
        "竞争对手.*推荐",
        "品牌.*提及",
        "可见度",
    )
    negative_kw = (
        "写一篇",
        "解释一下",
        "抓取",
        "关键词研究",
        "保证",
        "收费网站",
        "公众号",
        "小红书推广",
        "爬虫",
    )
    # regex-style compound negative patterns
    negative_re = (
        r"部署.*平台",
        r"部署.*saaS",
        r"注册.*账号",
    )
    results = []
    with (EVAL_DIR / "trigger-prompts.csv").open(encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            prompt = (row["prompt"] or "").lower()
            should = str(row["should_trigger"]).lower() == "true"
            score_pos = sum(1 for k in positive_kw if k.lower() in prompt)
            # also check regex-style compound patterns
            import re as _re
            score_pos += sum(
                1 for k in ("竞争对手.*推荐", "品牌.*提及", "推荐.*分析")
                if _re.search(k, prompt)
            )
            score_neg = sum(1 for k in negative_kw if k.lower() in prompt)
            score_neg += sum(1 for k in negative_re if _re.search(k, prompt))
            predict = score_pos > 0 and score_neg == 0
            # special: SEO keyword research
            if "seo" in prompt and "geo" not in prompt:
                predict = False
            results.append(
                {
                    "id": row["id"],
                    "ok": predict == should,
                    "detail": f"predict={predict} should={should}",
                }
            )
    return results


def eval_security_cases() -> list[dict]:
    results = []
    for line in (EVAL_DIR / "security-cases.jsonl").read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        case = json.loads(line)
        # structural presence of expect field counts as documented policy case
        results.append({"id": case["id"], "ok": bool(case.get("expect")), "detail": case.get("expect")})
    return results


def eval_security_structural() -> list[dict]:
    """Verify security-relevant code structures exist."""
    results = []
    skill_md = (SKILL_ROOT / "SKILL.md").read_text(encoding="utf-8")

    # SKILL.md safety section
    results.append({
        "id": "SEC_SKILL_SAFETY",
        "ok": "## Safety" in skill_md,
        "detail": "SKILL.md must contain Safety section",
    })
    results.append({
        "id": "SEC_NO_SECRETS",
        "ok": "Never read secrets" in skill_md or "never read secrets" in skill_md.lower(),
        "detail": "SKILL.md must prohibit reading secrets",
    })
    results.append({
        "id": "SEC_NO_FABRICATE",
        "ok": "fabricate" in skill_md.lower() or "Never fabricate" in skill_md,
        "detail": "SKILL.md must prohibit fabricating citations",
    })
    results.append({
        "id": "SEC_NO_GUARANTEE",
        "ok": "guarantee rankings" in skill_md.lower() or "guarantee" in skill_md.lower(),
        "detail": "SKILL.md must prohibit guaranteeing rankings",
    })

    # geo_common.py must have forbidden promise patterns
    geo_src = (SCRIPTS / "geo_common.py").read_text(encoding="utf-8")
    results.append({
        "id": "SEC_FORBIDDEN_PROMISES",
        "ok": "FORBIDDEN_PROMISE_PATTERNS" in geo_src,
        "detail": "geo_common.py must define FORBIDDEN_PROMISE_PATTERNS",
    })

    # path containment
    results.append({
        "id": "SEC_PATH_CONTAINMENT",
        "ok": "resolve_under" in geo_src and "escapes base directory" in geo_src,
        "detail": "geo_common.py must have path containment logic (resolve_under)",
    })

    # validate_report checks forbidden patterns
    vr_src = (SCRIPTS / "validate_report.py").read_text(encoding="utf-8")
    results.append({
        "id": "SEC_REPORT_VALIDATES_PROMISES",
        "ok": "FORBIDDEN_PROMISE_PATTERNS" in vr_src,
        "detail": "validate_report.py must check FORBIDDEN_PROMISE_PATTERNS",
    })
    results.append({
        "id": "SEC_REPORT_TRACEABILITY",
        "ok": "evidence_urls" in vr_src and "UNTRACEABLE_URL" in vr_src,
        "detail": "validate_report.py must verify URL traceability",
    })

    # input validation sensitive scan
    vi_src = (SCRIPTS / "validate_input.py").read_text(encoding="utf-8")
    results.append({
        "id": "SEC_INPUT_SENSITIVE_SCAN",
        "ok": "scan_sensitive" in vi_src and "api_key" in vi_src.lower(),
        "detail": "validate_input.py must scan for sensitive data patterns",
    })

    return results


def eval_workflow_cases() -> list[dict]:
    results = []
    for line in (EVAL_DIR / "workflow-cases.jsonl").read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        case = json.loads(line)
        results.append({"id": case["id"], "ok": case.get("expected") is True, "detail": case.get("check")})
    return results


def main() -> int:
    import argparse
    parser = argparse.ArgumentParser(description="Run geo-brand-audit evals")
    parser.add_argument("--output", default=None, help="Save JSON report to file")
    args, _ = parser.parse_known_args()

    all_results = []
    all_results.extend(eval_metric_fixtures())
    all_results.extend(eval_trigger_heuristic())
    all_results.extend(eval_security_cases())
    all_results.extend(eval_security_structural())
    all_results.extend(eval_workflow_cases())
    failed = [r for r in all_results if not r["ok"]]
    report = {
        "total": len(all_results),
        "passed": len(all_results) - len(failed),
        "failed": len(failed),
        "failures": failed,
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if args.output:
        from geo_common import write_json
        write_json(Path(args.output), report)
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())